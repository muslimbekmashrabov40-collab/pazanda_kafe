/* ============================================================
   PAZANDA SAYTI SOZLAMALARI
   Faqat shu faylni o'zgartirsangiz kifoya: telefon, manzil,
   bot, to'lov, aksiya va boshqalar shu yerda.
   ============================================================ */
const SOZLAMA = {
  NOM: "Pazanda",
  TELEFON: "+998943248308",
  MANZIL: "Farg'ona viloyati, Uchko'prik tumani",
  ISH_VAQTI: { hafta: "10:00 – 23:00", dam: "09:00 – 00:00" },

  /* ---- BUYURTMALAR QAYERGA KELADI ----
     A) TAVSIYA: server varianti (worker papkasiga qarang, ULASH.md).
        API_URL ga worker manzilini yozing. Bu holda token saytda ko'rinmaydi.
     B) Sinov uchun: API_URL ni bo'sh qoldiring, BOT_TOKEN va CHAT_ID ni yozing.
        Bu usulda token sayt kodida ochiq turadi, saytni internetga chiqarishdan
        oldin A variantiga o'ting. */
  API_URL: "",
  BOT_TOKEN: "9186522096:AAG4VWJ4aSkLmaDF0ssWSLMqSSE8cEyOi3s",
  CHAT_ID: "8807783366",

  /* ---- XARITA ----
     qidiruv: xaritada qidiriladigan matn. Aniq joy uchun restoran manzilini
     yozing (masalan: "Uchko'prik, Navoiy ko'chasi 12") yoki lat/lng qo'ying. */
  HARITA: { qidiruv: "Uchko'prik tumani, Farg'ona viloyati", lat: "", lng: "" },

  /* ---- KUN TAOMI VA CHEGIRMA ----
     nom: menyudagi taom nomi (aynan shunday yozilishi kerak). Bo'sh qoldirsangiz o'chadi.
     chegirma: foizda (10 degani 10%). Server ulangan bo'lsa, admin sahifadan ham o'zgartirsa bo'ladi. */
  KUN_TAOMI: { nom: "To'y oshi", chegirma: 10 },

  /* ---- TO'LOV USULLARI ----
     Naqd pul doim bor. Qolganlari to'ldirilsagina chiqadi.
     karta: karta raqami (mijoz o'tkazma qiladi), kartaEgasi: ism familiya.
     payme / click: ularning "merchant" shartnomasi kerak. Bo'sh qoldirsangiz chiqmaydi.
     To'lov tushganini siz o'zingiz tekshirasiz, sayt buni avtomatik bilmaydi. */
  TO_LOV: {
    karta: "", kartaEgasi: "",
    payme: "",            // Payme merchant ID
    paymeMaydon: "order_id",
    clickServis: "", clickMerchant: ""
  },

  /* ---- GALEREYA ----
     rasmlar/ papkasiga rasm tashlang va nomini shu yerga yozing:
     GALEREYA: ["zal1.jpg", "zal2.jpg", "oshxona.jpg"] */
  GALEREYA: [],

  /* ---- FIKRLAR ----
     Haqiqiy mijozlar fikrini qo'lda qo'shish uchun: [{ism:"Aziz", baho:5, matn:"..."}]
     Server ulangan bo'lsa, mijozlar saytdan fikr yozadi, siz botda "Saytda ko'rsatish"
     tugmasini bossangiz, fikr avtomatik chiqadi. */
  FIKRLAR: []
};
