# Pazanda sayti: ishga tushirish qo'llanmasi

## Papkada nima bor

| Fayl | Nima uchun |
|---|---|
| `index.html`, `style.css`, `app.js` | Sayt o'zi |
| `sozlamalar.js` | **Telefon, manzil, bot, to'lov, aksiya shu yerda** |
| `menyu.js` | 150 taom (3 tilda). Uni `admin.html` orqali tahrirlaysiz |
| `admin.html` | Narx, taom, "Hozir yo'q", kun taomi va chegirmani o'zgartirish |
| `rasmlar/` | Taom va galereya rasmlari. `ROYXAT.txt` da har bir taom uchun fayl nomi yozilgan |
| `worker/` | Server varianti (tokenni yashiradi). Saytni internetga chiqarishdan oldin ulang |

## 1. Kompyuterda sinab ko'rish (5 daqiqa)

1. `index.html` ni Chrome'da oching (Telegram ichidan emas).
2. `@pazanda_001_bot` da **Start** bosilgan bo'lishi kerak.
3. Manzil oxiriga `#test` qo'shib (`.../index.html#test`) sahifani yangilang. Botga "ulandi" xabari kelishi kerak.
4. Savatga taom qo'shing, buyurtma bering. Botda **Qabul qilish / Bekor qilish** tugmalari chiqadi. Qabul qilsangiz, saytda chek ochiladi. Keyin tugmalar **Tayyorlanmoqda → Yo'lda (yoki Tayyor) → Topshirildi** ga almashadi, mijoz saytda ko'radi.

Bu rejimda token `sozlamalar.js` ichida ochiq turadi. **Faqat sinov uchun.** Saytni internetga qo'yishdan oldin 4-bo'limga o'ting.

## 2. Rasmlar

- Taom rasmi: `rasmlar/` ga tashlang, nomi `rasmlar/ROYXAT.txt` dagidek bo'lsin (masalan `toy-oshi.jpg`). Rasm bo'lmasa, sayt bo'limga mos belgi ko'rsatadi.
- Galereya: rasmlarni `rasmlar/` ga qo'ying va `sozlamalar.js` da `GALEREYA: ["zal1.jpg", "zal2.jpg"]` deb yozing.
- Tavsiya: 800×600 piksel, har biri 150 KB dan kichik.

## 3. Menyuni o'zgartirish (admin.html)

`admin.html` ni oching: narx, tavsif, Xit belgisi, "Hozir yo'q" (tugagan taom), go'shtsiz/achchiq/bolalar belgilari, yangi taom qo'shish, o'chirish.

- **Server ulangan bo'lsa:** parolni yozib **Saytga saqlash** bosing. Sayt darrov yangilanadi, telefondan ham qilsa bo'ladi.
- **Server ulanmagan bo'lsa:** **menyu.js ni yuklab olish** bosing va fayl o'rnini almashtiring.

## 4. Server (Cloudflare Worker) ulash

Nima beradi: token saytdan yashirinadi, ko'p mijoz bir vaqtda buyurtma bersa ham holatlar adashmaydi, narxlar serverda tekshiriladi, admin sahifadan menyu saqlanadi, mijoz fikrlari sizning tasdig'ingizdan keyin chiqadi.

Cloudflare tugmalari vaqt o'tishi bilan o'zgarishi mumkin, nomlari taxminan shunday:

1. `dash.cloudflare.com` da bepul ro'yxatdan o'ting.
2. **Workers & Pages → Create → Worker**. Nomi `pazanda`. **Deploy** bosing, keyin **Edit code** ni bosib, ichidagi hamma narsani o'chiring va `worker/worker.js` ning to'liq matnini qo'ying. **Deploy**.
3. **Storage / KV** bo'limida yangi namespace yarating, nomi `PZ`.
4. Worker sahifasida **Settings → Bindings → Add → KV namespace**. Variable name: `PZ`, namespace: yaratgan `PZ` ni tanlang.
5. **Settings → Variables and Secrets** da 4 ta **Secret** qo'shing:
   - `BOT_TOKEN`: botning tokeni
   - `CHAT_ID`: buyurtmalar keladigan chat raqami (sizda `8807783366`)
   - `ADMIN_PASSWORD`: o'zingiz o'ylab topgan uzun parol (admin sahifaga kirish uchun)
   - `WEBHOOK_SECRET`: tasodifiy harf va raqamlar, masalan `k39Fh2LqPz81vXa7` (faqat lotin harflari, raqam, `_` va `-`)
6. Brauzerda oching: `https://pazanda.SIZNING-NOM.workers.dev/setup?key=ADMIN_PAROLINGIZ`. `"ok":true` chiqsa va Telegramda "serveri botga ulandi" xabari kelsa, tayyor.
7. `sozlamalar.js` da:
   - `API_URL: "https://pazanda.SIZNING-NOM.workers.dev"`
   - `BOT_TOKEN: ""` va `CHAT_ID: ""` (bo'sh qoldiring, kerak emas)

Terminal bilan qulay bo'lsangiz, shu papkada `npx wrangler deploy` va `npx wrangler secret put BOT_TOKEN` (qolganlari ham shunday) ishlatsa bo'ladi. `wrangler.toml` tayyor.

Muhim: server ulangach bot "webhook" rejimiga o'tadi, shuning uchun 1-bo'limdagi to'g'ridan-to'g'ri sinov endi ishlamaydi. Sinash uchun saytning o'zidan buyurtma bering.

## 5. Internetga chiqarish

1. **Tokenni tekshiring:** `sozlamalar.js` da `BOT_TOKEN` bo'sh va `API_URL` to'ldirilgan bo'lsin.
2. Papkani bepul joylashtirish xizmatlaridan biriga yuklang: Netlify (`app.netlify.com/drop` ga papkani tashlash), Cloudflare Pages yoki GitHub Pages. Tayyor manzil beradi.
3. O'z domeningiz (masalan `pazanda.uz`) uchun domen sotuvchi ro'yxatidan sotib olib, xizmatning "Custom domain" bo'limiga ulanadi. Narxini sotuvchidan tekshiring.
4. Xaritada aniq joy chiqishi uchun `sozlamalar.js` da `HARITA.qidiruv` ga restoran manzilini aniq yozing yoki `lat` va `lng` ni qo'ying (Google Maps'da joyni bosib, koordinatani nusxalang).

## 6. To'lov

- **Naqd:** doim bor.
- **Kartaga o'tkazma:** `TO_LOV.karta` va `kartaEgasi` ni yozsangiz chiqadi. Buyurtmani qabul qilganingizdan keyin mijozga karta raqami va summa ko'rsatiladi.
- **Payme / Click:** ularning merchant shartnomasi kerak. `payme`, `clickServis`, `clickMerchant` ni to'ldirsangiz, qabul qilingach mijozga "To'lash" tugmasi chiqadi.

Sayt to'lov tushganini **o'zi bilmaydi**. Pulni o'z hisobingizda tekshirasiz. Avtomatik tasdiqlash uchun Payme/Click bilan alohida server integratsiyasi kerak, bu hozircha qo'shilmagan.

## 7. Bilib qo'ying

- Mijoz fikrlari server ulangan bo'lsagina saytda chiqadi. Botda **Saytda ko'rsatish** tugmasini bossangiz chiqadi. Qo'lda qo'shish uchun `FIKRLAR` ga yozing. Soxta fikr yozmang.
- Taom nomlari o'zbekcha qoladi (osh, lag'mon), tavsif va bo'limlar 3 tilda.
- Cloudflare bepul tarifida kunlik so'rovlar chegarasi bor. Buyurtmalar ko'payib ketsa, uning narxlari va limitlarini Cloudflare saytidan tekshiring.
- Tokenni hech kimga yubormang. Fosh bo'lsa, @BotFather da `/revoke` qilib yangisini oling va Worker'dagi `BOT_TOKEN` ni almashtiring.
