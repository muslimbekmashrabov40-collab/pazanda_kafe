/* PAZANDA SERVERI (Cloudflare Worker)
   Vazifasi:
   - Telegram tokenini saytdan yashiradi (token faqat shu yerda, maxfiy o'zgaruvchida turadi)
   - Buyurtmalarni qabul qiladi, botga tugmalar bilan yuboradi
   - Bot tugmalari bosilganda holatni saqlaydi, sayt uni so'rab turadi
   - Menyu, narx va "kun taomi"ni admin sahifadan saqlaydi
   - Mijozlar fikrini siz tasdiqlagandan keyin saytda ko'rsatadi

   Kerakli sozlamalar (ULASH.md da qadamma-qadam yozilgan):
     KV namespace, binding nomi: PZ
     Maxfiy o'zgaruvchilar: BOT_TOKEN, CHAT_ID, ADMIN_PASSWORD, WEBHOOK_SECRET
*/

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET,POST,OPTIONS',
  'access-control-allow-headers': 'content-type,x-admin',
  'access-control-max-age': '86400'
};
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json; charset=utf-8', ...CORS } });
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const fmtU = n => Math.round(n).toLocaleString('ru-RU').replace(/ /g, ' ') + " so'm";
const stamp = () => new Date().toLocaleString('ru-RU', { timeZone: 'Asia/Tashkent' });
const clean = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n);
const disc = (p, ch) => Math.round(p * (100 - ch) / 100 / 100) * 100;
const rid = () => { const a = new Uint8Array(4); crypto.getRandomValues(a); return Array.from(a, x => x.toString(36)).join('').toUpperCase().slice(0, 5).padEnd(5, 'X'); };
const same = (a, b) => { a = String(a || ''); b = String(b || ''); if (a.length !== b.length || !a) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; };

const TUR_U = { delivery: "Yetkazib berish", dine: "Zalda yeyman", pickup: "Olib ketaman" };
const PAY_U = { cash: "Naqd pul", card: "Kartaga o'tkazma", payme: "Payme", click: "Click" };
const STATUS_LINE = { new: '🆕 YANGI', accepted: '✅ QABUL QILINDI', cooking: '👨‍🍳 TAYYORLANMOQDA', ready: '🍽 TAYYOR', onway: "🚚 YO'LDA", done: '🏁 TOPSHIRILDI', cancelled: '❌ BEKOR QILINDI' };
const ACT = {
  ok: { from: ['new'], to: 'accepted' }, no: { from: ['new', 'accepted', 'cooking'], to: 'cancelled' },
  cook: { from: ['accepted'], to: 'cooking' }, way: { from: ['cooking'], to: 'onway' },
  ready: { from: ['cooking'], to: 'ready' }, done: { from: ['onway', 'ready'], to: 'done' }
};

function orderText(o, status) {
  const lines = o.items.map((x, i) => `${i + 1}. ${esc(x.n)} × ${x.q} = ${fmtU(x.p * x.q)}`);
  return ['🧾 <b>Buyurtma № ' + o.id + '</b>', '', '👤 ' + esc(o.ism), '📞 ' + esc(o.tel), '🚚 ' + TUR_U[o.tur],
    o.man ? '📍 ' + esc(o.man) : null, o.izoh ? '💬 ' + esc(o.izoh) : null, '💳 ' + PAY_U[o.pay], '', ...lines, '',
    '💰 <b>Jami: ' + fmtU(o.total) + '</b>', '🕒 ' + o.time, '', '<b>' + STATUS_LINE[status] + '</b>'].filter(x => x !== null).join('\n');
}
function keyboard(status, o) {
  const b = (tx, a) => ({ text: tx, callback_data: a + ':' + o.id });
  switch (status) {
    case 'new': return [[b('✅ Qabul qilish', 'ok'), b('❌ Bekor qilish', 'no')]];
    case 'accepted': return [[b('👨‍🍳 Tayyorlanmoqda', 'cook'), b('❌ Bekor qilish', 'no')]];
    case 'cooking': return [[o.tur === 'delivery' ? b("🚚 Yo'lda", 'way') : b('🍽 Tayyor', 'ready'), b('❌ Bekor qilish', 'no')]];
    case 'onway': case 'ready': return [[b('🏁 Topshirildi', 'done')]];
    default: return [];
  }
}

async function tg(env, method, body) {
  const r = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!j.ok) throw new Error(j.description || 'telegram');
  return j.result;
}
async function rate(env, ip, kind, max) {
  const k = `rl:${kind}:${ip}`, n = +(await env.PZ.get(k)) || 0;
  if (n >= max) return false;
  await env.PZ.put(k, String(n + 1), { expirationTtl: 600 });
  return true;
}
async function readBody(req, max = 20000) {
  const txt = await req.text();
  if (txt.length > max) throw new Error('Juda katta so\'rov');
  return JSON.parse(txt || '{}');
}
async function getCfg(env) {
  try { return JSON.parse(await env.PZ.get('cfg')) || null; } catch (_) { return null; }
}

/* ---------- buyurtma ---------- */
async function createOrder(req, env) {
  const ip = req.headers.get('cf-connecting-ip') || 'x';
  if (!(await rate(env, ip, 'o', 8))) return json({ error: "Juda ko'p buyurtma. Birozdan keyin urinib ko'ring." }, 429);
  let b; try { b = await readBody(req); } catch (e) { return json({ error: "Noto'g'ri so'rov" }, 400); }
  const ism = clean(b.ism, 60), tel = clean(b.tel, 20);
  const tur = ['delivery', 'dine', 'pickup'].includes(b.tur) ? b.tur : null;
  const pay = ['cash', 'card', 'payme', 'click'].includes(b.pay) ? b.pay : 'cash';
  if (!ism || !tur || tel.replace(/\D/g, '').length < 9) return json({ error: "Ism, telefon yoki buyurtma turi noto'g'ri" }, 400);
  const man = tur === 'pickup' ? '' : clean(b.man, 150);
  if (tur === 'delivery' && !man) return json({ error: 'Yetkazib berish uchun manzil kerak' }, 400);
  if (!Array.isArray(b.items) || !b.items.length || b.items.length > 60) return json({ error: "Savat bo'sh yoki juda katta" }, 400);

  const cfg = await getCfg(env), price = {};
  if (cfg && Array.isArray(cfg.menu)) cfg.menu.forEach(c => c.items.forEach(i => { price[i.n] = i; }));
  const items = [];
  for (const x of b.items) {
    const n = clean(x.n, 80), q = Math.floor(+x.q);
    if (!n || !(q >= 1 && q <= 50)) return json({ error: "Taom yoki soni noto'g'ri" }, 400);
    let p = Math.floor(+x.p);
    if (cfg && cfg.menu) {
      const m = price[n];
      if (!m) return json({ error: `"${n}" menyuda yo'q` }, 400);
      if (m.off) return json({ error: `"${n}" hozir mavjud emas` }, 400);
      p = (cfg.kun && cfg.kun.nom === n && cfg.kun.chegirma > 0) ? disc(m.p, cfg.kun.chegirma) : m.p;
    }
    if (!(p >= 0 && p <= 5000000)) return json({ error: "Narx noto'g'ri" }, 400);
    items.push({ n, q, p });
  }
  const o = { id: 'P-' + rid(), time: stamp(), ts: Date.now(), ism, tel, tur, man, izoh: clean(b.izoh, 150), pay, items, total: items.reduce((s, x) => s + x.p * x.q, 0) };
  let m;
  try { m = await tg(env, 'sendMessage', { chat_id: env.CHAT_ID, text: orderText(o, 'new'), parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard('new', o) } }); }
  catch (e) { return json({ error: "Botga yuborib bo'lmadi: " + e.message }, 502); }
  await env.PZ.put('o:' + o.id, JSON.stringify({ status: 'new', order: o, mid: m.message_id }), { expirationTtl: 7 * 86400 });
  return json({ id: o.id, total: o.total, items: o.items });
}
async function orderStatus(url, env) {
  const id = clean(url.searchParams.get('id'), 20);
  const rec = id && JSON.parse((await env.PZ.get('o:' + id)) || 'null');
  if (!rec) return json({ error: 'Topilmadi' }, 404);
  return json({ status: rec.status });
}

/* ---------- joy band qilish, fikr ---------- */
async function booking(req, env) {
  const ip = req.headers.get('cf-connecting-ip') || 'x';
  if (!(await rate(env, ip, 'b', 6))) return json({ error: "Juda ko'p so'rov" }, 429);
  let b; try { b = await readBody(req); } catch (e) { return json({ error: "Noto'g'ri so'rov" }, 400); }
  const ism = clean(b.ism, 60), tel = clean(b.tel, 20);
  if (!ism || tel.replace(/\D/g, '').length < 9) return json({ error: "Ism yoki telefon noto'g'ri" }, 400);
  const text = ['📅 <b>Joy band qilish</b>', '', '👤 ' + esc(ism), '📞 ' + esc(tel), '🗓 ' + esc(clean(b.kun, 12)) + ' ' + esc(clean(b.vaqt, 8)), '👥 ' + esc(clean(b.soni, 6)) + ' kishi', '', '🕒 ' + stamp()].join('\n');
  try { await tg(env, 'sendMessage', { chat_id: env.CHAT_ID, text, parse_mode: 'HTML' }); } catch (e) { return json({ error: "Botga yuborib bo'lmadi: " + e.message }, 502); }
  return json({ ok: true });
}
async function review(req, env) {
  const ip = req.headers.get('cf-connecting-ip') || 'x';
  if (!(await rate(env, ip, 'r', 3))) return json({ error: "Juda ko'p so'rov" }, 429);
  let b; try { b = await readBody(req); } catch (e) { return json({ error: "Noto'g'ri so'rov" }, 400); }
  const r = { ism: clean(b.ism, 40), baho: Math.max(1, Math.min(5, Math.floor(+b.baho) || 5)), matn: clean(b.matn, 400) };
  if (!r.ism || !r.matn) return json({ error: "Ism va fikr kerak" }, 400);
  const id = rid();
  await env.PZ.put('rp:' + id, JSON.stringify(r), { expirationTtl: 30 * 86400 });
  const text = ['⭐ <b>Yangi fikr</b> ' + '★'.repeat(r.baho), '', '👤 ' + esc(r.ism), '💬 ' + esc(r.matn)].join('\n');
  try {
    await tg(env, 'sendMessage', { chat_id: env.CHAT_ID, text, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: "✅ Saytda ko'rsatish", callback_data: 'rvok:' + id }, { text: '🗑 Rad etish', callback_data: 'rvno:' + id }]] } });
  } catch (e) { return json({ error: "Botga yuborib bo'lmadi: " + e.message }, 502); }
  return json({ ok: true });
}

/* ---------- menyu (admin) ---------- */
function validCfg(c) {
  if (!c || !Array.isArray(c.menu) || c.menu.length < 1 || c.menu.length > 30) return false;
  let total = 0; const seen = new Set();
  for (const cat of c.menu) {
    if (!cat || typeof cat.id !== 'string' || !cat.n || !Array.isArray(cat.items)) return false;
    for (const i of cat.items) {
      total++;
      if (typeof i.n !== 'string' || !i.n || i.n.length > 80 || seen.has(i.n)) return false;
      seen.add(i.n);
      if (!(Number.isFinite(i.p) && i.p >= 0 && i.p <= 5000000) || !i.d || typeof i.d !== 'object') return false;
    }
  }
  if (total > 500) return false;
  if (c.kun && !(typeof c.kun.nom === 'string' && c.kun.chegirma >= 0 && c.kun.chegirma <= 90)) return false;
  return true;
}
async function saveMenu(req, env) {
  if (!same(req.headers.get('x-admin'), env.ADMIN_PASSWORD)) return json({ error: "Parol noto'g'ri" }, 401);
  let b; try { b = await readBody(req, 400000); } catch (e) { return json({ error: "Noto'g'ri so'rov" }, 400); }
  if (!validCfg(b)) return json({ error: "Menyu formati noto'g'ri (nomlar takrorlanmasin, narx raqam bo'lsin)" }, 400);
  await env.PZ.put('cfg', JSON.stringify({ menu: b.menu, kun: b.kun || { nom: '', chegirma: 0 } }));
  return json({ ok: true });
}

/* ---------- Telegram webhook ---------- */
async function webhook(req, env) {
  if (!same(req.headers.get('x-telegram-bot-api-secret-token'), env.WEBHOOK_SECRET)) return new Response('forbidden', { status: 403 });
  const u = await req.json().catch(() => ({}));
  const cq = u.callback_query;
  if (!cq || !cq.data || !cq.message) return new Response('ok');
  const answer = text => tg(env, 'answerCallbackQuery', { callback_query_id: cq.id, text }).catch(() => {});
  if (String(cq.message.chat.id) !== String(env.CHAT_ID)) { await answer("Ruxsat yo'q"); return new Response('ok'); }
  const [act, id] = String(cq.data).split(':');
  const chat = cq.message.chat.id, mid = cq.message.message_id;

  if (act === 'rvok' || act === 'rvno') {
    const r = JSON.parse((await env.PZ.get('rp:' + id)) || 'null');
    if (!r) { await answer('Fikr topilmadi yoki allaqachon ko\'rib chiqilgan'); return new Response('ok'); }
    await env.PZ.delete('rp:' + id);
    if (act === 'rvok') {
      const list = JSON.parse((await env.PZ.get('rv')) || '[]');
      list.unshift(r);
      await env.PZ.put('rv', JSON.stringify(list.slice(0, 30)));
    }
    await tg(env, 'editMessageText', { chat_id: chat, message_id: mid, text: (act === 'rvok' ? "✅ Saytda ko'rsatilmoqda\n\n" : '🗑 Rad etildi\n\n') + '👤 ' + esc(r.ism) + '\n💬 ' + esc(r.matn), parse_mode: 'HTML', reply_markup: { inline_keyboard: [] } }).catch(() => {});
    await answer(act === 'rvok' ? "Saytda ko'rsatiladi" : 'Rad etildi');
    return new Response('ok');
  }
  const rule = ACT[act];
  const rec = rule && JSON.parse((await env.PZ.get('o:' + id)) || 'null');
  if (!rec) { await answer('Buyurtma topilmadi'); return new Response('ok'); }
  if (!rule.from.includes(rec.status)) { await answer("Holat allaqachon o'zgargan"); return new Response('ok'); }
  rec.status = rule.to;
  await env.PZ.put('o:' + id, JSON.stringify(rec), { expirationTtl: 7 * 86400 });
  await tg(env, 'editMessageText', { chat_id: chat, message_id: rec.mid || mid, text: orderText(rec.order, rec.status), parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard(rec.status, rec.order) } }).catch(() => {});
  await answer(STATUS_LINE[rec.status]);
  return new Response('ok');
}
async function setup(url, env) {
  if (!same(url.searchParams.get('key'), env.ADMIN_PASSWORD)) return json({ error: "Parol noto'g'ri" }, 401);
  try {
    const hook = await tg(env, 'setWebhook', { url: `${url.origin}/hook`, secret_token: env.WEBHOOK_SECRET, allowed_updates: ['callback_query'], drop_pending_updates: true });
    await tg(env, 'sendMessage', { chat_id: env.CHAT_ID, text: '✅ Pazanda serveri botga ulandi.' });
    return json({ ok: true, webhook: hook });
  } catch (e) { return json({ ok: false, error: e.message }, 502); }
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url), p = url.pathname.replace(/\/+$/, '') || '/';
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    try {
      if (req.method === 'GET') {
        if (p === '/') return json({ ok: true, nom: 'pazanda' });
        if (p === '/status') return orderStatus(url, env);
        if (p === '/menu') return json(await getCfg(env) || { menu: null });
        if (p === '/reviews') return json({ reviews: JSON.parse((await env.PZ.get('rv')) || '[]') });
        if (p === '/setup') return setup(url, env);
      } else if (req.method === 'POST') {
        if (p === '/order') return createOrder(req, env);
        if (p === '/booking') return booking(req, env);
        if (p === '/review') return review(req, env);
        if (p === '/menu') return saveMenu(req, env);
        if (p === '/hook') return webhook(req, env);
      }
    } catch (e) { return json({ error: 'Server xatosi' }, 500); }
    return json({ error: 'Topilmadi' }, 404);
  }
};
