(function () {
'use strict';
const C = SOZLAMA;
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const slug = s => s.toLowerCase().replace(/[ʻ'’`]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} },
  del(k) { try { localStorage.removeItem(k); } catch (_) {} }
};
const API = (C.API_URL || '').replace(/\/+$/, '');
const DIRECT = !API;

/* ============ TARJIMALAR ============ */
const T = {
uz: {
  nav_menu:"Menyu", nav_about:"Biz haqimizda", nav_book:"Joy band qilish", nav_reviews:"Fikrlar", nav_contact:"Aloqa",
  hero_h1:"Kazanda pishgan, dasturxonda sovumaydi",
  hero_p:"Har kuni ertalab yangi damlangan to'y oshi, tandirdan uzilgan issiq samsa va ko'mir ustida pishgan shashlik. Oila bilan keling, joyingiz tayyor.",
  btn_book:"Joy band qilish", btn_menu:"Menyuni ko'rish", kazan:"Har kuni\nsoat 12:00 da\nosh tayyor",
  today:"Kun taomi:", add:"+ Savatga", added:"Qo'shildi ✓", off:"Hozir yo'q", hit:"Xit",
  menu_title:"Menyu", menu_sub:"xil taom. Narxlar so'mda, barcha taomlar buyurtma bilan yangi tayyorlanadi.",
  search_ph:"Taomni qidiring, masalan: osh", cat_all:"Barchasi", no_results:"Hech narsa topilmadi. Boshqa nom yoki filtr bilan urinib ko'ring.",
  f_all:"Hammasi", f_veg:"Go'shtsiz", f_spicy:"Achchiq", f_kids:"Bolalar uchun", f_hit:"Xit taomlar",
  tag_veg:"Go'shtsiz", tag_spicy:"Achchiq", tag_kids:"Bolalar uchun", cur:"so'm",
  about_title:"Biz haqimizda", about_p:"Pazanda oilaviy restoran. Retseptlarimiz bobolarimizdan qolgan, masalliqlar esa har kuni mahalliy bozordan olinadi.",
  f1_h:"Yangi masalliq", f1_p:"Go'sht, sabzi va guruch har kuni ertalab yangi keltiriladi.",
  f2_h:"Katta dasturxon", f2_p:"Zalimiz 80 kishigacha, alohida xonalar to'y va tug'ilgan kunlar uchun.",
  f3_h:"Yetkazib berish", f3_p:"Buyurtmangizni issiq holda yetkazamiz.",
  gal_title:"Galereya",
  book_title:"Joy band qilish", book_sub:"Ma'lumotlaringizni qoldiring, administrator sizga qo'ng'iroq qilib tasdiqlaydi.",
  wd:"Dushanba — Juma", we:"Shanba — Yakshanba", phone:"Telefon", address:"Manzil", hours:"Ish vaqti",
  f_name:"Ismingiz", f_phone:"Telefon raqamingiz", f_date:"Kun", f_time:"Vaqt", f_guests:"Mehmonlar soni", book_btn:"Joyni band qilish",
  book_ok:"Rahmat! So'rovingiz qabul qilindi, tez orada qo'ng'iroq qilamiz.",
  rv_title:"Mehmonlar fikri", rv_sub:"Bizda bo'ldingizmi? Fikringizni yozing, restoran tasdiqlagach saytda chiqadi.",
  rv_rate:"Baho", rv_text:"Fikringiz", rv_btn:"Fikrni yuborish", rv_ok:"Rahmat! Fikringiz yuborildi.",
  contact_title:"Aloqa", contact_sub:"Savolingiz bo'lsa yoki joy band qilmoqchi bo'lsangiz, qo'ng'iroq qiling.", route:"Yo'l ko'rsat",
  cart_btn:"Savat", cart_title:"Buyurtmangiz", cart_empty:"Savat bo'sh. Menyudan taom tanlang.", total:"Jami",
  f_type:"Qanday olasiz?", tur_delivery:"Yetkazib berish", tur_dine:"Zalda yeyman", tur_pickup:"Olib ketaman",
  man_delivery:"Yetkazish manzili", man_dine:"Stol raqami (ixtiyoriy)", f_note:"Izoh (ixtiyoriy)", f_pay:"To'lov usuli",
  pay_cash:"Naqd pul", pay_card:"Kartaga o'tkazma", pay_payme:"Payme", pay_click:"Click", order_btn:"Buyurtma berish",
  v_empty:"Savat bo'sh. Avval menyudan taom tanlang.", v_addr:"Yetkazib berish uchun manzilni yozing.", v_phone:"Telefon raqamni to'liq yozing.",
  sending:"Yuborilmoqda...", confirm_new:"Joriy buyurtma kuzatuvi to'xtaydi. Yangi buyurtma berasizmi?",
  st_new:"Yuborildi", st_accepted:"Qabul qilindi", st_cooking:"Tayyorlanmoqda", st_ready:"Tayyor", st_onway:"Yo'lda", st_done:"Topshirildi", st_cancelled:"Bekor qilindi", st_timeout:"Javob kelmadi",
  stx_new:"Restoran tasdiqlashini kutyapmiz. Sahifani yopmang, holat shu yerda yangilanadi.",
  stx_accepted:"Buyurtmangiz qabul qilindi. Chekingiz tayyor.", stx_cooking:"Oshpazlarimiz buyurtmangizni tayyorlayapti.",
  stx_ready:"Buyurtmangiz tayyor, olib ketishingiz mumkin.", stx_onway:"Kuryer yo'lda, tez orada yetib boradi.", stx_done:"Buyurtma topshirildi. Yoqimli ishtaha!",
  stx_cancelled:"Afsuski, restoran buyurtmani qabul qila olmadi. Savol bo'lsa qo'ng'iroq qiling:", stx_timeout:"Restoran hali javob bermadi. Qo'ng'iroq qilib so'rang:",
  order_no:"Buyurtma №", see_receipt:"Chekni ko'rish", new_order:"Yangi buyurtma",
  pay_card_h:"Kartaga o'tkazing:", pay_amount:"Summa:", pay_copy:"Karta raqamini nusxalash", pay_copied:"Nusxalandi ✓", pay_open:"To'lash",
  pay_note:"To'lov tushganini restoran tekshiradi.",
  ck_no:"Chek №", ck_date:"Sana", ck_cust:"Mijoz", ck_phone:"Telefon", ck_type:"Turi", ck_addr:"Manzil", ck_pay:"To'lov", ck_status:"Holat",
  ck_thanks:"Rahmat! Yana kutib qolamiz.", ck_print:"Chop etish / PDF", ck_close:"Yopish",
  e_config:"Bot hali ulanmagan: sozlamalar.js faylida BOT_TOKEN va CHAT_ID (yoki API_URL) ni to'ldiring.",
  e_token:"Bot tokeni noto'g'ri. sozlamalar.js dagi BOT_TOKEN ni tekshiring.",
  e_chat:"Bot sizga yoza olmayapti. Telegramda botga kirib Start bosing va CHAT_ID to'g'riligini tekshiring.",
  e_net:"Ulanib bo'lmadi. Internetni tekshiring (VPN yoki filtr bo'lsa o'chirib ko'ring) va qayta urinib ko'ring.",
  e_other:"Yuborib bo'lmadi: "
},
ru: {
  nav_menu:"Меню", nav_about:"О нас", nav_book:"Бронь стола", nav_reviews:"Отзывы", nav_contact:"Контакты",
  hero_h1:"Из казана на стол, пока горячее",
  hero_p:"Каждое утро свежий свадебный плов, горячая самса из тандыра и шашлык на углях. Приходите всей семьёй, стол вас ждёт.",
  btn_book:"Забронировать стол", btn_menu:"Смотреть меню", kazan:"Каждый день\nв 12:00\nплов готов",
  today:"Блюдо дня:", add:"+ В корзину", added:"Добавлено ✓", off:"Нет в наличии", hit:"Хит",
  menu_title:"Меню", menu_sub:"блюд. Цены в сумах, всё готовится под заказ.",
  search_ph:"Поиск блюда, например: плов", cat_all:"Все", no_results:"Ничего не найдено. Попробуйте другое название или фильтр.",
  f_all:"Все", f_veg:"Без мяса", f_spicy:"Острое", f_kids:"Для детей", f_hit:"Хиты",
  tag_veg:"Без мяса", tag_spicy:"Острое", tag_kids:"Для детей", cur:"сум",
  about_title:"О нас", about_p:"Pazanda — семейный ресторан. Рецепты достались нам от дедов, а продукты каждый день берём на местном рынке.",
  f1_h:"Свежие продукты", f1_p:"Мясо, морковь и рис привозят каждое утро.",
  f2_h:"Большой стол", f2_p:"Зал до 80 человек, отдельные залы для свадеб и дней рождения.",
  f3_h:"Доставка", f3_p:"Привезём ваш заказ горячим.",
  gal_title:"Галерея",
  book_title:"Бронь стола", book_sub:"Оставьте данные, администратор перезвонит и подтвердит.",
  wd:"Пн — Пт", we:"Сб — Вс", phone:"Телефон", address:"Адрес", hours:"Часы работы",
  f_name:"Ваше имя", f_phone:"Ваш телефон", f_date:"Дата", f_time:"Время", f_guests:"Число гостей", book_btn:"Забронировать",
  book_ok:"Спасибо! Заявка принята, скоро перезвоним.",
  rv_title:"Отзывы гостей", rv_sub:"Были у нас? Напишите отзыв, он появится на сайте после проверки.",
  rv_rate:"Оценка", rv_text:"Ваш отзыв", rv_btn:"Отправить отзыв", rv_ok:"Спасибо! Отзыв отправлен.",
  contact_title:"Контакты", contact_sub:"Есть вопросы или хотите забронировать стол? Звоните.", route:"Проложить маршрут",
  cart_btn:"Корзина", cart_title:"Ваш заказ", cart_empty:"Корзина пуста. Выберите блюда в меню.", total:"Итого",
  f_type:"Как получите?", tur_delivery:"Доставка", tur_dine:"В зале", tur_pickup:"Самовывоз",
  man_delivery:"Адрес доставки", man_dine:"Номер стола (необязательно)", f_note:"Комментарий (необязательно)", f_pay:"Способ оплаты",
  pay_cash:"Наличными", pay_card:"Перевод на карту", pay_payme:"Payme", pay_click:"Click", order_btn:"Оформить заказ",
  v_empty:"Корзина пуста. Сначала выберите блюда.", v_addr:"Укажите адрес для доставки.", v_phone:"Введите телефон полностью.",
  sending:"Отправляем...", confirm_new:"Отслеживание текущего заказа прекратится. Оформить новый заказ?",
  st_new:"Отправлен", st_accepted:"Принят", st_cooking:"Готовится", st_ready:"Готов", st_onway:"В пути", st_done:"Выдан", st_cancelled:"Отменён", st_timeout:"Нет ответа",
  stx_new:"Ждём подтверждения ресторана. Не закрывайте страницу, статус обновится здесь.",
  stx_accepted:"Заказ принят. Ваш чек готов.", stx_cooking:"Повара готовят ваш заказ.",
  stx_ready:"Заказ готов, можно забирать.", stx_onway:"Курьер в пути, скоро будет.", stx_done:"Заказ выдан. Приятного аппетита!",
  stx_cancelled:"К сожалению, ресторан не смог принять заказ. Если есть вопросы, позвоните:", stx_timeout:"Ресторан пока не ответил. Позвоните и уточните:",
  order_no:"Заказ №", see_receipt:"Показать чек", new_order:"Новый заказ",
  pay_card_h:"Переведите на карту:", pay_amount:"Сумма:", pay_copy:"Скопировать номер карты", pay_copied:"Скопировано ✓", pay_open:"Оплатить",
  pay_note:"Поступление оплаты проверит ресторан.",
  ck_no:"Чек №", ck_date:"Дата", ck_cust:"Клиент", ck_phone:"Телефон", ck_type:"Тип", ck_addr:"Адрес", ck_pay:"Оплата", ck_status:"Статус",
  ck_thanks:"Спасибо! Ждём вас снова.", ck_print:"Печать / PDF", ck_close:"Закрыть",
  e_config:"Бот ещё не подключён: заполните BOT_TOKEN и CHAT_ID (или API_URL) в файле sozlamalar.js.",
  e_token:"Неверный токен бота. Проверьте BOT_TOKEN в sozlamalar.js.",
  e_chat:"Бот не может вам писать. Откройте бота в Telegram, нажмите Start и проверьте CHAT_ID.",
  e_net:"Нет соединения. Проверьте интернет (отключите VPN или фильтр) и повторите.",
  e_other:"Не удалось отправить: "
},
en: {
  nav_menu:"Menu", nav_about:"About", nav_book:"Book a table", nav_reviews:"Reviews", nav_contact:"Contact",
  hero_h1:"Cooked in the kazan, served while it's hot",
  hero_p:"Fresh wedding plov every morning, hot samsa straight from the tandoor and shashlik grilled over coals. Come with the family, your table is ready.",
  btn_book:"Book a table", btn_menu:"See the menu", kazan:"Every day\nplov is ready\nat 12:00",
  today:"Dish of the day:", add:"+ Add", added:"Added ✓", off:"Unavailable", hit:"Hit",
  menu_title:"Menu", menu_sub:"dishes. Prices in UZS, everything is cooked to order.",
  search_ph:"Search a dish, e.g. plov", cat_all:"All", no_results:"Nothing found. Try another name or filter.",
  f_all:"All", f_veg:"Meat-free", f_spicy:"Spicy", f_kids:"For kids", f_hit:"Best sellers",
  tag_veg:"Meat-free", tag_spicy:"Spicy", tag_kids:"For kids", cur:"UZS",
  about_title:"About us", about_p:"Pazanda is a family restaurant. Our recipes come from our grandparents and we buy ingredients at the local market every day.",
  f1_h:"Fresh ingredients", f1_p:"Meat, carrots and rice are delivered every morning.",
  f2_h:"A big table", f2_p:"A hall for up to 80 guests and private rooms for weddings and birthdays.",
  f3_h:"Delivery", f3_p:"We bring your order to you hot.",
  gal_title:"Gallery",
  book_title:"Book a table", book_sub:"Leave your details and the administrator will call you to confirm.",
  wd:"Mon — Fri", we:"Sat — Sun", phone:"Phone", address:"Address", hours:"Opening hours",
  f_name:"Your name", f_phone:"Your phone", f_date:"Date", f_time:"Time", f_guests:"Guests", book_btn:"Book the table",
  book_ok:"Thank you! Your request is received, we will call you soon.",
  rv_title:"Guest reviews", rv_sub:"Been to us? Write a review, it appears here once the restaurant approves it.",
  rv_rate:"Rating", rv_text:"Your review", rv_btn:"Send review", rv_ok:"Thank you! Your review was sent.",
  contact_title:"Contact", contact_sub:"Questions or want to book a table? Give us a call.", route:"Get directions",
  cart_btn:"Cart", cart_title:"Your order", cart_empty:"Your cart is empty. Pick dishes from the menu.", total:"Total",
  f_type:"How do you want it?", tur_delivery:"Delivery", tur_dine:"Dine in", tur_pickup:"Pickup",
  man_delivery:"Delivery address", man_dine:"Table number (optional)", f_note:"Note (optional)", f_pay:"Payment method",
  pay_cash:"Cash", pay_card:"Card transfer", pay_payme:"Payme", pay_click:"Click", order_btn:"Place order",
  v_empty:"Your cart is empty. Pick dishes first.", v_addr:"Enter a delivery address.", v_phone:"Enter the full phone number.",
  sending:"Sending...", confirm_new:"Tracking of the current order will stop. Place a new order?",
  st_new:"Sent", st_accepted:"Accepted", st_cooking:"Cooking", st_ready:"Ready", st_onway:"On the way", st_done:"Delivered", st_cancelled:"Cancelled", st_timeout:"No reply",
  stx_new:"Waiting for the restaurant to confirm. Keep this page open, the status updates here.",
  stx_accepted:"Your order is accepted. Your receipt is ready.", stx_cooking:"Our cooks are preparing your order.",
  stx_ready:"Your order is ready for pickup.", stx_onway:"The courier is on the way.", stx_done:"Order delivered. Enjoy your meal!",
  stx_cancelled:"Sorry, the restaurant could not accept your order. Please call:", stx_timeout:"The restaurant has not replied yet. Please call:",
  order_no:"Order #", see_receipt:"View receipt", new_order:"New order",
  pay_card_h:"Transfer to the card:", pay_amount:"Amount:", pay_copy:"Copy card number", pay_copied:"Copied ✓", pay_open:"Pay now",
  pay_note:"The restaurant will confirm the payment.",
  ck_no:"Receipt #", ck_date:"Date", ck_cust:"Customer", ck_phone:"Phone", ck_type:"Type", ck_addr:"Address", ck_pay:"Payment", ck_status:"Status",
  ck_thanks:"Thank you! See you again.", ck_print:"Print / PDF", ck_close:"Close",
  e_config:"The bot is not connected yet: fill in BOT_TOKEN and CHAT_ID (or API_URL) in sozlamalar.js.",
  e_token:"Invalid bot token. Check BOT_TOKEN in sozlamalar.js.",
  e_chat:"The bot cannot message you. Open the bot in Telegram, press Start and check CHAT_ID.",
  e_net:"Could not connect. Check your internet (turn off VPN or filters) and try again.",
  e_other:"Could not send: "
}};
let lang = store.get('pz_lang', null);
if (!T[lang]) lang = ((navigator.language || '').slice(0, 2) === 'ru') ? 'ru' : 'uz';
const t = k => (T[lang][k] !== undefined ? T[lang][k] : (T.uz[k] !== undefined ? T.uz[k] : k));
const tu = k => T.uz[k];
const loc = o => (o && (o[lang] || o.uz)) || '';
const fmtN = n => Math.round(n).toLocaleString('ru-RU').replace(/ /g, ' ');
const fmt = n => fmtN(n) + ' ' + t('cur');
const fmtU = n => fmtN(n) + " so'm";
const stamp = () => new Date().toLocaleString('ru-RU', { timeZone: 'Asia/Tashkent' });
const telShow = p => p.replace(/^\+998(\d{2})(\d{3})(\d{2})(\d{2})$/, '+998 $1 $2 $3 $4');

/* ============ MENYU MA'LUMOTI ============ */
let MENU_DATA = (typeof MENU !== 'undefined') ? MENU : [];
let KUN = C.KUN_TAOMI || {};
let byName = {};
function indexMenu() {
  byName = {};
  MENU_DATA.forEach(c => c.items.forEach(i => { byName[i.n] = { it: i, cid: c.id }; }));
  Object.keys(cart).forEach(k => { if (!byName[k]) delete cart[k]; });
}
const disc = (p, ch) => Math.round(p * (100 - ch) / 100 / 100) * 100;
const hasSale = it => KUN && KUN.nom === it.n && KUN.chegirma > 0;
const priceOf = it => hasSale(it) ? disc(it.p, KUN.chegirma) : it.p;

/* ============ SAVAT ============ */
let cart = store.get('pz_cart', {});
const count = () => Object.values(cart).reduce((a, b) => a + b, 0);
const sum = () => Object.entries(cart).reduce((s, [n, q]) => s + priceOf(byName[n].it) * q, 0);
function saveCart() { store.set('pz_cart', cart); }
function addToCart(n, d) {
  if (!byName[n] || byName[n].it.off) return;
  cart[n] = (cart[n] || 0) + d;
  if (cart[n] <= 0) delete cart[n];
  saveCart(); drawCart();
}
function drawCart() {
  const names = Object.keys(cart);
  $('clist').innerHTML = names.length ? names.map(n => {
    const it = byName[n].it;
    return `<li><div><b>${esc(n)}</b><br><small>${fmt(priceOf(it))}</small></div>
      <div class="qty"><button type="button" data-n="${esc(n)}" data-d="-1" aria-label="-">−</button><span>${cart[n]}</span><button type="button" data-n="${esc(n)}" data-d="1" aria-label="+">+</button></div></li>`;
  }).join('') : `<li class="empty">${esc(t('cart_empty'))}</li>`;
  $('ctotal').textContent = fmt(sum());
  drawCartBtn();
}
function drawCartBtn() {
  const b = $('cartbtn');
  if (pend) b.innerHTML = `${esc(t('order_no'))}${esc(pend.id)}: ${esc(t('st_' + viewKind(pend)))}`;
  else b.innerHTML = `${esc(t('cart_btn'))} <span id="cnt">${count()}</span>`;
}
function openCart(o) {
  $('drawer').classList.toggle('open', o);
  $('scrim').classList.toggle('open', o);
  $('drawer').setAttribute('aria-hidden', String(!o));
  if (o) $('dclose').focus();
}

/* ============ MENYU CHIZISH ============ */
let cat = 'all', filt = 'all';
function renderTabs() {
  const tabs = [['all', t('cat_all'), MENU_DATA.reduce((a, c) => a + c.items.length, 0)]]
    .concat(MENU_DATA.map(c => [c.id, loc(c.n), c.items.length]));
  $('tabs').innerHTML = tabs.map(([id, n, k]) =>
    `<button class="tab" type="button" role="tab" data-cat="${esc(id)}" aria-selected="${id === cat}">${esc(n)} (${k})</button>`).join('');
  const fl = [['all', 'f_all'], ['veg', 'f_veg'], ['spicy', 'f_spicy'], ['kids', 'f_kids'], ['hit', 'f_hit']];
  $('chips').innerHTML = fl.map(([id, k]) => `<button class="chip" type="button" data-f="${id}" aria-pressed="${id === filt}">${esc(t(k))}</button>`).join('');
}
function dishHTML(it, cid) {
  const img = it.img || (slug(it.n) + '.jpg');
  const tags = (it.tags || []).map(g => `<span class="${g === 'spicy' ? 'sp' : ''}">${esc(t('tag_' + g))}</span>`).join('');
  const sale = hasSale(it);
  return `<article class="dish${it.off ? ' off' : ''}">
    <div class="pic c-${esc(cid)}"><svg aria-hidden="true"><use href="#ic-${esc(cid)}"/></svg><img src="rasmlar/${esc(img)}" alt="${esc(it.n)}" loading="lazy">
      ${it.hit ? `<em class="hit">${esc(t('hit'))}</em>` : ''}${sale ? `<em class="sale">−${KUN.chegirma}%</em>` : ''}</div>
    <div class="dbody"><h3>${esc(it.n)}</h3><p>${esc(loc(it.d))}</p>${tags ? `<div class="tags">${tags}</div>` : ''}
      <div class="dfoot"><span>${sale ? `<s>${fmt(it.p)}</s>` : ''}<b>${fmt(priceOf(it))}</b></span>
      <button class="add" type="button" data-n="${esc(it.n)}"${it.off ? ' disabled' : ''}>${esc(it.off ? t('off') : t('add'))}</button></div></div></article>`;
}
function renderMenu() {
  const q = $('q').value.trim().toLowerCase();
  const groups = [];
  MENU_DATA.forEach(c => {
    if (!q && cat !== 'all' && c.id !== cat) return;
    const items = c.items.filter(it => {
      if (filt === 'hit' && !it.hit) return false;
      if (filt !== 'all' && filt !== 'hit' && !(it.tags || []).includes(filt)) return false;
      if (q && !(it.n + ' ' + it.d.uz + ' ' + loc(it.d)).toLowerCase().includes(q)) return false;
      return true;
    });
    if (items.length) groups.push([c, items]);
  });
  const showHead = cat === 'all' || !!q;
  $('menu-out').innerHTML = groups.length ? groups.map(([c, items]) =>
    (showHead ? `<h3 class="grp">${esc(loc(c.n))}</h3>` : '') +
    `<div class="menu">${items.map(i => dishHTML(i, c.id)).join('')}</div>`).join('')
    : `<p class="empty">${esc(t('no_results'))}</p>`;
}
function renderToday() {
  const e = KUN && byName[KUN.nom];
  $('today').hidden = !(e && KUN.chegirma > 0 && !e.it.off);
  if ($('today').hidden) return;
  $('today-name').textContent = KUN.nom;
  $('today-old').textContent = fmt(e.it.p);
  $('today-new').textContent = fmt(priceOf(e.it));
  $('today-pct').textContent = '(−' + KUN.chegirma + '%)';
}
$('tabs').addEventListener('click', e => { const b = e.target.closest('.tab'); if (!b) return; cat = b.dataset.cat; $('q').value = ''; renderTabs(); renderMenu(); });
$('chips').addEventListener('click', e => { const b = e.target.closest('.chip'); if (!b) return; filt = b.dataset.f; renderTabs(); renderMenu(); });
$('q').addEventListener('input', renderMenu);
$('menu-out').addEventListener('error', e => { if (e.target.tagName === 'IMG') e.target.remove(); }, true);
$('menu-out').addEventListener('click', e => {
  const b = e.target.closest('.add'); if (!b) return;
  addToCart(b.dataset.n, 1);
  b.textContent = t('added');
  setTimeout(() => { if (b.isConnected && !b.disabled) b.textContent = t('add'); }, 900);
});
$('today-add').onclick = () => { if (KUN && byName[KUN.nom]) { addToCart(KUN.nom, 1); openCart(true); } };
$('clist').addEventListener('click', e => { const b = e.target.closest('button'); if (b) addToCart(b.dataset.n, +b.dataset.d); });
$('cartbtn').onclick = () => openCart(true);
$('dclose').onclick = $('scrim').onclick = () => openCart(false);
document.addEventListener('keydown', e => { if (e.key === 'Escape') { openCart(false); $('chekwrap').hidden = true; } });

/* ============ TELEGRAM (to'g'ridan-to'g'ri rejim) ============ */
async function tg(method, params) {
  if (!C.BOT_TOKEN || !C.CHAT_ID || /BU_YERGA/.test(C.BOT_TOKEN + C.CHAT_ID)) throw new Error('config');
  const res = await fetch('https://api.telegram.org/bot' + C.BOT_TOKEN + '/' + method, { method: 'POST', body: new URLSearchParams(params) });
  const j = await res.json().catch(() => ({}));
  if (!res.ok || !j.ok) throw new Error(j.description || ('HTTP ' + res.status));
  return j.result;
}
async function api(path, body) {
  const opt = body === undefined ? {} : { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) };
  const res = await fetch(API + path, opt);
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j.error || ('HTTP ' + res.status));
  return j;
}
function explain(err) {
  const m = (err && err.message) || '';
  if (m === 'config') return t('e_config');
  if (/chat not found|initiate|blocked|deactivated|forbidden/i.test(m)) return t('e_chat');
  if (/unauthorized|token/i.test(m)) return t('e_token');
  if (/failed to fetch|networkerror|load failed/i.test(m)) return t('e_net');
  return t('e_other') + m;
}
const TUR_U = { delivery: "Yetkazib berish", dine: "Zalda yeyman", pickup: "Olib ketaman" };
const PAY_U = { cash: "Naqd pul", card: "Kartaga o'tkazma", payme: "Payme", click: "Click" };
const STATUS_LINE = { new: '🆕 YANGI', accepted: '✅ QABUL QILINDI', cooking: '👨‍🍳 TAYYORLANMOQDA', ready: '🍽 TAYYOR', onway: "🚚 YO'LDA", done: '🏁 TOPSHIRILDI', cancelled: '❌ BEKOR QILINDI' };
const ACT = {
  ok: { from: ['new'], to: 'accepted' }, no: { from: ['new', 'accepted', 'cooking'], to: 'cancelled' },
  cook: { from: ['accepted'], to: 'cooking' }, way: { from: ['cooking'], to: 'onway' },
  ready: { from: ['cooking'], to: 'ready' }, done: { from: ['onway', 'ready'], to: 'done' }
};
function orderText(o, status) {
  const lines = o.items.map((x, i) => `${i + 1}. ${esc(x.n)} × ${x.q} = ${fmtU(x.p * x.q)}`);
  return ['🧾 <b>Buyurtma № ' + o.id + '</b>', '', '👤 ' + esc(o.ism), '📞 ' + esc(o.tel), '🚚 ' + TUR_U[o.tur],
    o.man ? '📍 ' + esc(o.man) : null, o.izoh ? '💬 ' + esc(o.izoh) : null, '💳 ' + PAY_U[o.pay], '', ...lines, '',
    '💰 <b>Jami: ' + fmtU(o.total) + '</b>', '🕒 ' + o.time, '', '<b>' + STATUS_LINE[status] + '</b>'].filter(x => x !== null).join('\n');
}
function keyboard(status, o) {
  const b = (tx, a) => ({ text: tx, callback_data: a + ':' + o.id });
  switch (status) {
    case 'new': return [[b('✅ Qabul qilish', 'ok'), b('❌ Bekor qilish', 'no')]];
    case 'accepted': return [[b('👨‍🍳 Tayyorlanmoqda', 'cook'), b('❌ Bekor qilish', 'no')]];
    case 'cooking': return [[o.tur === 'delivery' ? b("🚚 Yo'lda", 'way') : b('🍽 Tayyor', 'ready'), b('❌ Bekor qilish', 'no')]];
    case 'onway': case 'ready': return [[b('🏁 Topshirildi', 'done')]];
    default: return [];
  }
}

/* ============ JOY BAND QILISH ============ */
async function sendSimple(path, payload, text) {
  if (!DIRECT) return api(path, payload);
  return tg('sendMessage', { chat_id: C.CHAT_ID, text, parse_mode: 'HTML' });
}
function wireSimple(formId, msgId, okKey, path, mk, textFn) {
  const form = $(formId), msg = $(msgId);
  form.addEventListener('submit', async e => {
    e.preventDefault(); msg.className = 'msg';
    const f = Object.fromEntries(new FormData(form).entries());
    if (f.tel !== undefined && f.tel.replace(/\D/g, '').length < 9) { msg.textContent = t('v_phone'); msg.className = 'msg bad'; return; }
    const btn = form.querySelector('button[type=submit]'), old = btn.textContent;
    btn.disabled = true; btn.textContent = t('sending');
    try { await sendSimple(path, mk(f), textFn(f)); msg.textContent = t(okKey); msg.className = 'msg good'; form.reset(); setDefaults(); }
    catch (err) { msg.textContent = explain(err); msg.className = 'msg bad'; }
    finally { btn.disabled = false; btn.textContent = old; }
  });
}
wireSimple('bron', 'ok', 'book_ok', '/booking', f => f,
  f => ['📅 <b>Joy band qilish</b>', '', '👤 ' + esc(f.ism), '📞 ' + esc(f.tel), '🗓 ' + esc(f.kun) + ' ' + esc(f.vaqt), '👥 ' + esc(f.soni) + ' kishi', '', '🕒 ' + stamp()].join('\n'));
wireSimple('rvform', 'rvmsg', 'rv_ok', '/review', f => f,
  f => ['⭐ <b>Yangi fikr</b> ' + '★'.repeat(+f.baho), '', '👤 ' + esc(f.ism), '💬 ' + esc(f.matn), '', DIRECT ? "(Saytda ko'rsatish uchun server variantini ulang)" : ''].join('\n'));
function setDefaults() {
  const d = new Date(Date.now() + 5 * 3600e3).toISOString().slice(0, 10);
  const k = document.querySelector('#bron [name=kun]'); k.min = d; if (!k.value) k.value = d;
  const v = document.querySelector('#bron [name=vaqt]'); if (!v.value) v.value = '19:00';
}

/* ============ BUYURTMA ============ */
let pend = store.get('pz_pend', null);
let pollTimer = null, polling = false;
const WAIT_MS = 60 * 60 * 1000;
const TERMINAL = s => s === 'done' || s === 'cancelled';
const viewKind = o => (o.status === 'new' && Date.now() - o.ts > WAIT_MS) ? 'timeout' : o.status;
const savePend = () => pend ? store.set('pz_pend', pend) : store.del('pz_pend');

function buildPayOptions() {
  const P = C.TO_LOV || {}, sel = $('o-pay'), keep = sel.value;
  const opts = ['cash'];
  if (P.karta) opts.push('card');
  if (P.payme) opts.push('payme');
  if (P.clickServis && P.clickMerchant) opts.push('click');
  sel.innerHTML = opts.map(k => `<option value="${k}">${esc(t('pay_' + k))}</option>`).join('');
  if (opts.includes(keep)) sel.value = keep;
}
function syncTur() {
  const tur = $('o-tur').value, l = $('o-man-l');
  l.hidden = tur === 'pickup';
  $('o-man-t').textContent = t(tur === 'delivery' ? 'man_delivery' : 'man_dine');
}
$('o-tur').addEventListener('change', syncTur);

$('order').addEventListener('submit', async e => {
  e.preventDefault();
  const msg = $('omsg'), f = Object.fromEntries(new FormData($('order')).entries());
  msg.className = 'msg';
  const bad = x => { msg.textContent = x; msg.className = 'msg bad'; };
  if (!count()) return bad(t('v_empty'));
  if (f.tel.replace(/\D/g, '').length < 9) return bad(t('v_phone'));
  const man = (f.manzil || '').trim();
  if (f.tur === 'delivery' && !man) return bad(t('v_addr'));
  const o = {
    id: 'P-' + Math.random().toString(36).slice(2, 7).toUpperCase(), ts: Date.now(), time: stamp(), status: 'new', lang,
    ism: f.ism.trim(), tel: f.tel.trim(), tur: f.tur, man: f.tur === 'pickup' ? '' : man, izoh: (f.izoh || '').trim(), pay: f.pay || 'cash',
    items: Object.entries(cart).map(([n, q]) => ({ n, q, p: priceOf(byName[n].it) })), total: 0, lastUpd: 0
  };
  o.total = o.items.reduce((s, x) => s + x.p * x.q, 0);
  const btn = $('order').querySelector('button[type=submit]'), old = btn.textContent;
  btn.disabled = true; btn.textContent = t('sending');
  try {
    if (DIRECT) {
      const r = await tg('sendMessage', { chat_id: C.CHAT_ID, text: orderText(o, 'new'), parse_mode: 'HTML', reply_markup: JSON.stringify({ inline_keyboard: keyboard('new', o) }) });
      o.mid = r.message_id;
    } else {
      const j = await api('/order', { ism: o.ism, tel: o.tel, tur: o.tur, man: o.man, izoh: o.izoh, pay: o.pay, lang, items: o.items });
      o.id = j.id; if (j.total) o.total = j.total; if (j.items) o.items = j.items;
    }
    pend = o; savePend();
    cart = {}; saveCart(); drawCart(); $('order').reset(); syncTur();
    renderStatus(); startPolling();
  } catch (err) { bad(explain(err)); }
  finally { btn.disabled = false; btn.textContent = old; }
});

function stepList(o) {
  return ['new', 'accepted', 'cooking', o.tur === 'delivery' ? 'onway' : 'ready', 'done'];
}
function payURL(o) {
  const P = C.TO_LOV || {};
  if (o.pay === 'payme' && P.payme) return 'https://checkout.paycom.uz/' + btoa(`m=${P.payme};ac.${P.paymeMaydon || 'order_id'}=${o.id};a=${o.total * 100}`);
  if (o.pay === 'click' && P.clickServis) return `https://my.click.uz/services/pay?service_id=${encodeURIComponent(P.clickServis)}&merchant_id=${encodeURIComponent(P.clickMerchant)}&amount=${o.total}&transaction_param=${encodeURIComponent(o.id)}`;
  return '';
}
function renderStatus() {
  const o = pend;
  $('cartbox').hidden = !!o; $('status').hidden = !o;
  drawCartBtn();
  if (!o) return;
  const k = viewKind(o);
  $('st-title').textContent = `${t('order_no')}${o.id}: ${t('st_' + k)}`;
  const tail = (k === 'cancelled' || k === 'timeout') ? ' ' + telShow(C.TELEFON) : '';
  $('st-text').textContent = t('stx_' + k) + tail;
  const steps = stepList(o), idx = steps.indexOf(o.status);
  $('st-steps').hidden = (k === 'cancelled' || k === 'timeout');
  $('st-steps').innerHTML = steps.map((s, i) => `<li class="${i < idx ? 'done' : i === idx ? (s === 'done' ? 'done' : 'now') : ''}">${esc(t('st_' + s))}</li>`).join('');
  const acc = idx >= 1 && o.status !== 'cancelled';
  $('st-receipt').hidden = !acc;
  const pb = $('st-pay'); pb.hidden = true; pb.innerHTML = '';
  const P = C.TO_LOV || {};
  if (acc && o.status !== 'done') {
    if (o.pay === 'card' && P.karta) {
      pb.hidden = false;
      pb.innerHTML = `<div>${esc(t('pay_card_h'))}</div><b>${esc(P.karta)}</b><div>${esc(P.kartaEgasi || '')}</div><div>${esc(t('pay_amount'))} <b>${fmt(o.total)}</b></div>
        <button class="btn light" type="button" id="copycard">${esc(t('pay_copy'))}</button><small>${esc(t('pay_note'))}</small>`;
      $('copycard').onclick = async ev => { try { await navigator.clipboard.writeText(P.karta.replace(/\s/g, '')); ev.target.textContent = t('pay_copied'); } catch (_) {} };
    } else if (payURL(o)) {
      pb.hidden = false;
      pb.innerHTML = `<div>${esc(t('pay_amount'))} <b>${fmt(o.total)}</b></div><a class="btn" target="_blank" rel="noopener" href="${esc(payURL(o))}">${esc(t('pay_open'))}</a><small>${esc(t('pay_note'))}</small>`;
    }
  }
  $('st-new').hidden = false;
}
function showReceipt(o) {
  const row = (a, b) => `<div><span>${esc(a)}</span><span>${esc(b)}</span></div>`;
  $('chek-meta').innerHTML = row(t('ck_no'), o.id) + row(t('ck_date'), o.time) + row(t('ck_cust'), o.ism) + row(t('ck_phone'), o.tel) +
    row(t('ck_type'), t('tur_' + o.tur)) + (o.man ? row(t('ck_addr'), o.man) : '') + row(t('ck_pay'), t('pay_' + o.pay)) + row(t('ck_status'), t('st_' + o.status));
  $('chek-rows').innerHTML = o.items.map(x => `<tr><td>${esc(x.n)} × ${x.q}</td><td>${fmt(x.p * x.q)}</td></tr>`).join('');
  $('chek-sum').textContent = fmt(o.total);
  $('chekwrap').hidden = false;
}
$('chek-close').onclick = () => { $('chekwrap').hidden = true; };
$('chek-print').onclick = () => window.print();
$('st-receipt').onclick = () => showReceipt(pend);
$('st-new').onclick = () => {
  if (pend && !TERMINAL(pend.status) && viewKind(pend) !== 'timeout' && !confirm(t('confirm_new'))) return;
  stopPolling(); pend = null; savePend(); renderStatus();
};

function stopPolling() { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } }
function startPolling() { stopPolling(); if (!pend || TERMINAL(pend.status)) return; pollTimer = setInterval(poll, DIRECT ? 3000 : 4000); poll(); }
function applyStatus(s) {
  const o = pend; if (!o || o.status === s) return;
  const first = o.status === 'new' && s !== 'new';
  o.status = s; savePend(); renderStatus();
  if (first && s !== 'cancelled') { showReceipt(o); }
  if (TERMINAL(s)) stopPolling();
}
async function poll() {
  const o = pend;
  if (!o) { stopPolling(); return; }
  if (viewKind(o) === 'timeout') { renderStatus(); stopPolling(); return; }
  if (polling) return;
  polling = true;
  try {
    if (!DIRECT) {
      const j = await api('/status?id=' + encodeURIComponent(o.id));
      if (j.status) applyStatus(j.status);
    } else {
      const ups = await tg('getUpdates', { allowed_updates: JSON.stringify(['callback_query']), timeout: 0, limit: 100 });
      let cur = o.status, last = null;
      for (const u of ups.sort((a, b) => a.update_id - b.update_id)) {
        const cq = u.callback_query; if (!cq || !cq.data || u.update_id <= (o.lastUpd || 0)) continue;
        const [act, id] = cq.data.split(':');
        if (id !== o.id || !ACT[act]) continue;
        o.lastUpd = u.update_id;
        if (ACT[act].from.includes(cur)) { cur = ACT[act].to; last = cq; }
      }
      if (cur !== o.status) {
        if (last) tg('answerCallbackQuery', { callback_query_id: last.id, text: STATUS_LINE[cur] }).catch(() => {});
        if (o.mid) tg('editMessageText', { chat_id: C.CHAT_ID, message_id: o.mid, text: orderText(o, cur), parse_mode: 'HTML', reply_markup: JSON.stringify({ inline_keyboard: keyboard(cur, o) }) }).catch(() => {});
        applyStatus(cur);
      } else savePend();
    }
  } catch (_) { /* keyingi urinishda qayta tekshiriladi */ }
  finally { polling = false; }
}

/* ============ FIKRLAR, GALEREYA, XARITA ============ */
let REVIEWS = (C.FIKRLAR || []).slice();
function renderReviews() {
  const l = $('rv-list');
  l.hidden = !REVIEWS.length;
  l.innerHTML = REVIEWS.map(r => `<div class="rv"><div class="st">${'★'.repeat(Math.max(1, Math.min(5, +r.baho || 5)))}</div><p>${esc(r.matn)}</p><small>${esc(r.ism)}</small></div>`).join('');
}
function renderGallery() {
  const g = C.GALEREYA || [];
  $('galereya').hidden = !g.length;
  $('gal').innerHTML = g.map(f => `<img src="rasmlar/${esc(f)}" alt="" loading="lazy">`).join('');
}
function renderMap() {
  const H = C.HARITA || {}, q = (H.lat && H.lng) ? `${H.lat},${H.lng}` : (H.qidiruv || C.MANZIL);
  $('map').src = `https://www.google.com/maps?q=${encodeURIComponent(q)}&output=embed&hl=${lang}`;
  $('route').href = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(q)}`;
  $('route-y').href = `https://yandex.com/maps/?text=${encodeURIComponent(q)}`;
}

/* ============ TIL VA UMUMIY MATNLAR ============ */
function applyI18n() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
  document.querySelectorAll('[data-i18n-aria]').forEach(el => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
  document.querySelectorAll('.langs button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.lang === lang)));
  const tur = $('o-tur').options; tur[0].text = t('tur_delivery'); tur[1].text = t('tur_dine'); tur[2].text = t('tur_pickup');
  $('dtitle').textContent = t('cart_title');
  document.title = `${C.NOM} | ${t('nav_menu')}`;
}
function fillStatic() {
  const tel = telShow(C.TELEFON);
  $('logo').textContent = C.NOM;
  ['navtel', 'h-tel', 'c-tel'].forEach(id => { $(id).textContent = tel; $(id).href = 'tel:' + C.TELEFON; });
  $('h-addr').textContent = $('c-addr').textContent = C.MANZIL;
  $('h-wd').textContent = C.ISH_VAQTI.hafta; $('h-we').textContent = C.ISH_VAQTI.dam;
  $('c-hours').textContent = C.ISH_VAQTI.hafta;
  $('ck-name').textContent = C.NOM; $('ck-addr').textContent = C.MANZIL; $('ck-tel').textContent = tel;
  $('f-left').textContent = `© ${new Date().getFullYear()} ${C.NOM}`;
  $('f-right').textContent = `${C.MANZIL} · ${tel}`;
}
function renderAll() {
  indexMenu();
  $('total').textContent = MENU_DATA.reduce((a, c) => a + c.items.length, 0);
  renderTabs(); renderMenu(); renderToday(); drawCart(); renderReviews(); renderMap(); buildPayOptions(); syncTur();
  if (pend) renderStatus();
}
function setLang(l) {
  lang = l; store.set('pz_lang', l); applyI18n(); renderAll();
}
document.querySelector('.langs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setLang(b.dataset.lang); });

/* ============ BOSHLASH ============ */
fillStatic(); renderGallery(); setDefaults(); applyI18n(); renderAll();
if (pend) startPolling();
if (API) {
  api('/menu').then(j => { if (j && j.menu) { MENU_DATA = j.menu; if (j.kun) KUN = j.kun; renderAll(); } }).catch(() => {});
  api('/reviews').then(j => { if (j && j.reviews) { REVIEWS = (C.FIKRLAR || []).concat(j.reviews); renderReviews(); } }).catch(() => {});
}
if (location.hash === '#test' && DIRECT) {
  tg('sendMessage', { chat_id: C.CHAT_ID, text: '✅ Pazanda sayti botga ulandi.' })
    .then(() => alert("Bot ulandi! Telegramni tekshiring, xabar kelgan bo'lishi kerak."))
    .catch(err => alert(explain(err)));
}
})();
